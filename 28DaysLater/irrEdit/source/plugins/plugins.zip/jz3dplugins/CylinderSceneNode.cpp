#include "CylinderSceneNode.h"

char *irr::scene::jz3d::CylinderSceneNode::Name = "Cylinder";