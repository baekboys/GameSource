#pragma once

//--------------------
//���丮 �÷����� ���
//--------------------
#include "jz3dplugins/JZ3DSceneNodeFactory.h"
#include "jz3dplugins/CollusionMngPluginNode.h"
#include "jz3dplugins/FormatedAnimationNode.h"
#include "jz3dplugins/TiledPlaneNode.h"
#include "jz3dplugins/BulletPhysicsObjectNode.h"
#include "jz3dplugins/irrKlangSceneNode.h"
#include "jz3dplugins/CylinderSceneNode.h"
#include "jz3dplugins/TiledPlaneNormalMapNode.h"