#include "DynamicObject.h"
#include "App.h"

CDynamicObject::CDynamicObject(void)
{
}

CDynamicObject::~CDynamicObject(void)
{
}

bool CDynamicObject::Init(irr::scene::jz3d::CBulletPhysicsObjectNode* pNode)
{
	irr::scene::ISceneManager *pSmgr = CApp::GetPtr()->m_pSmgr;
	irr::IrrlichtDevice *pDevice = CApp::GetPtr()->m_pDevice;
	irr::scene::CBulletAnimatorManager* pBulletPhysicsFactory = CApp::GetPtr()->m_pBulletPhysicsFactory; 
	irr::scene::CBulletWorldAnimator* pWorldAnimator = CApp::GetPtr()->m_pWorldAnimator;

	m_strTypeName="nonchar/dynamic";

	irr::scene::ISceneNode* node = pNode->getParent();
	m_pMainNode = node;

	irr::core::stringc name(node->getName());
	if (name == "cylinder")
	{
		m_type = DYNAMIC_METAL;
	}
	else if (name == "wood")
	{
		m_type = DYNAMIC_WOOD;
	}
	else if (name == "ball")
	{
		m_type = DYNAMIC_BALL;
	}

	{
		// ���� �ִϸ����� ���̱�
		irr::scene::CBulletObjectAnimator *pAnim = pBulletPhysicsFactory->createBulletObjectAnimator(
			pSmgr,
			m_pMainNode,
			pWorldAnimator->getID(),
			&(pNode->m_GeometryInfo),
			&(pNode->m_PhysicsParam)
			);

		m_pMainNode->addAnimator(pAnim);

		m_pAnimator = pAnim;
		pAnim->drop();
	}

	m_pAnimator->setPosition(m_pMainNode->getAbsolutePosition());

	return true;
}

void CDynamicObject::Signal(std::string strSignal,void *pParam)
{
	if ( strSignal == "damage")
	{
		if(m_pCollisionSound)
		{
			//m_pSoundEngine->play3D(m_pCollisionSound, getPosition());
		}
	}
}

void CDynamicObject::Update(irr::f32 fDelta)
{

}

bool CDynamicObject::isDie()
{
	return false;
}