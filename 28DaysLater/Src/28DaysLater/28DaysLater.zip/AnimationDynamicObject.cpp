#include "AnimationDynamicObject.h"
#include "App.h"

CAnimationDynamicObject::CAnimationDynamicObject(void)
{
}

CAnimationDynamicObject::~CAnimationDynamicObject(void)
{
}

bool CAnimationDynamicObject::Init(irr::scene::jz3d::CBulletPhysicsObjectNode* pNode)
{
	irr::scene::ISceneManager *pSmgr = CApp::GetPtr()->m_pSmgr;
	irr::IrrlichtDevice *pDevice = CApp::GetPtr()->m_pDevice;
	irr::scene::CBulletAnimatorManager* pBulletPhysicsFactory = CApp::GetPtr()->m_pBulletPhysicsFactory; 
	irr::scene::CBulletWorldAnimator* pWorldAnimator = CApp::GetPtr()->m_pWorldAnimator;

	m_strTypeName="nonchar/dynamic";

	irr::scene::ISceneNode* node = pNode->getParent();
	m_pFNode = static_cast<irr::scene::jz3d::CFormatedAnimationNode*>(node);

	irr::core::stringc name(node->getName());
	if (name == "metal")
	{
		m_type = DYNAMIC_METAL;
		m_hp = 200;
	}
	else if (name == "wood")
	{
		m_type = DYNAMIC_WOOD;
		m_hp = 100;
	}
	

	{
		// ���� �ִϸ����� ���̱�
		irr::scene::CBulletObjectAnimator *pAnim = pBulletPhysicsFactory->createBulletObjectAnimator(
			pSmgr,
			m_pFNode,
			pWorldAnimator->getID(),
			&(pNode->m_GeometryInfo),
			&(pNode->m_PhysicsParam)
			);

		m_pFNode->addAnimator(pAnim);

		m_pAnimator = pAnim;
		pAnim->drop();
	}

	m_pAnimator->setPosition(m_pFNode->getAbsolutePosition());

	SetStatus(ACTIVE);

	return true;
}

void CAnimationDynamicObject::Signal(std::string strSignal,void *pParam)
{
	if ( strSignal == "damage")
	{
		if(m_pCollisionSound)
		{
			//m_pSoundEngine->play3D(m_pCollisionSound, getPosition());
		}

		WeaponAttackDATA* data = static_cast<WeaponAttackDATA*>(pParam);
		m_hp -= data->damage;

		if(m_hp < 0)
		{
			SetStatus(BREAK);
		}
	}
}

void CAnimationDynamicObject::Update(irr::f32 fDelta)
{

}

bool CAnimationDynamicObject::isDie()
{
	return false;
}