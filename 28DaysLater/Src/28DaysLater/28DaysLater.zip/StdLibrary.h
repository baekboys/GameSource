#pragma once

//--------------
//ǥ�ض��̺귯��
//--------------
#include <memory>
#include <crtdbg.h>
#include <windows.h>
#include <atlcoll.h>
#include <vector>
#include <iostream>
#include <queue>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>