#pragma once

//---------
// ��ƿ��Ƽ
//---------
#include "Singleton.h"
#include "FSMObject.h"
#include "util.h"
#include "XmlReader.h"