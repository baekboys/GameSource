#pragma once

//-------------------
//�ϸ���Ʈ ���̺귯��
//-------------------
#include <irrlicht.h>
#include <irrKlang.h>
#pragma comment(lib, "irrKlang.lib") // link with irrKlang.dll
#pragma comment(lib,"irrlicht.lib")

