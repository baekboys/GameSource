Hey dudes, Just got round to finishing the zombie checkout the tuts on my site!!! (links' at the bottom)

OK, heres the frame info for the B3D (blitz basic) model format, I am classing the first frame as 1, and my anim starts at frame 2 as the first is just a standard pose for use when I animated him!! Details below, have fun and drop me a line and show me how your using him, hopefully he'll be stumbling around dark rooms and attacking people :-)

NOTE: He also needs to be rotated 180 degrees because He's currently facing the camera on IMPORT (unless thats what you want)

FRAMES:-

2-20	Walk cycle 1
22-36	Walk Cycle 2
38-47	Zombie being Attacked 1
48-57	Zombie being Attacked 2
59-75	Blown away onto his back
78-88	Still lying down and twitching (OFFSET to where he landed)
91-103	Die and fall forwards
106-115	Kick Attack
117-128	Punch/Grab Attack
129-136	Head Butt :-)
137-169	Idle 1
170-200	Idle 2


Hope you guys out there find him useful and as usual he's all for FREE to use however you like, Credits are greatly appreciated!!!!

Check out my sites at:-

http://xu1productions.com/3dstudio/index.html - 3d Game Resources

http://www.psionicdesign.com - My 2d/3d site

Cya's

Psionic